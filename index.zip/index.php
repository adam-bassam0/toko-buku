<?php

require_once 'config/auth.php';
require_once 'config/koneksi.php';

// Jumlah seluruh buku di keranjang untuk badge navbar.
$jumlahCart = array_sum($_SESSION['cart'] ?? []);

// --- Ambil Kategori & Hitung Buku ---
$resKategori = $koneksi->query(
    "SELECT k.id, k.nama, k.slug, COUNT(b.id) AS total_buku
     FROM kategori k
     LEFT JOIN buku b ON b.kategori_id = k.id
     GROUP BY k.id
     ORDER BY k.nama ASC"
);
$daftarKategori = $resKategori ? $resKategori->fetch_all(MYSQLI_ASSOC) : [];

// Hitung total semua buku di database
$resTotalBuku = $koneksi->query("SELECT COUNT(*) AS total FROM buku");
$totalSemuaBuku = $resTotalBuku ? (int) $resTotalBuku->fetch_assoc()['total'] : 0;

// --- Parameter Pencarian & Kategori ---
$kataCari      = isset($_GET['cari']) ? trim($_GET['cari']) : '';
$kategoriParam = isset($_GET['kategori']) ? trim($_GET['kategori']) : '';

// Cari data kategori aktif
$kategoriAktif = null;
if ($kategoriParam !== '') {
    foreach ($daftarKategori as $kat) {
        if ($kat['slug'] === $kategoriParam || (string) $kat['id'] === $kategoriParam) {
            $kategoriAktif = $kat;
            break;
        }
    }
}

// Icon helper untuk kategori
function getKategoriIcon(string $slug): string {
    return match($slug) {
        'fiksi-sastra'      => 'bi-magic',
        'pengembangan-diri' => 'bi-graph-up-arrow',
        'komik-manga'       => 'bi-emoji-smile',
        'pelajaran-sains'   => 'bi-mortarboard',
        'agama-filsafat'    => 'bi-brightness-high',
        'anak-anak'         => 'bi-balloon',
        default             => 'bi-tag-fill'
    };
}

// --- Query Buku Berdasarkan Filter ---
if ($kataCari !== '' && $kategoriAktif !== null) {
    $stmt = $koneksi->prepare(
        "SELECT b.*, k.nama AS nama_kategori, k.slug AS slug_kategori
         FROM buku b
         LEFT JOIN kategori k ON b.kategori_id = k.id
         WHERE (b.judul LIKE ? OR b.penulis LIKE ?) AND b.kategori_id = ?
         ORDER BY b.judul ASC"
    );
    $paramCari = "%" . $kataCari . "%";
    $katId = (int) $kategoriAktif['id'];
    $stmt->bind_param("ssi", $paramCari, $paramCari, $katId);
    $stmt->execute();
    $result = $stmt->get_result();
} elseif ($kataCari !== '') {
    $stmt = $koneksi->prepare(
        "SELECT b.*, k.nama AS nama_kategori, k.slug AS slug_kategori
         FROM buku b
         LEFT JOIN kategori k ON b.kategori_id = k.id
         WHERE b.judul LIKE ? OR b.penulis LIKE ?
         ORDER BY b.judul ASC"
    );
    $paramCari = "%" . $kataCari . "%";
    $stmt->bind_param("ss", $paramCari, $paramCari);
    $stmt->execute();
    $result = $stmt->get_result();
} elseif ($kategoriAktif !== null) {
    $stmt = $koneksi->prepare(
        "SELECT b.*, k.nama AS nama_kategori, k.slug AS slug_kategori
         FROM buku b
         LEFT JOIN kategori k ON b.kategori_id = k.id
         WHERE b.kategori_id = ?
         ORDER BY b.id DESC"
    );
    $katId = (int) $kategoriAktif['id'];
    $stmt->bind_param("i", $katId);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $koneksi->query(
        "SELECT b.*, k.nama AS nama_kategori, k.slug AS slug_kategori
         FROM buku b
         LEFT JOIN kategori k ON b.kategori_id = k.id
         ORDER BY b.id DESC"
    );
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BukuKu — Toko Buku Digital Pilihan</title>
    <!-- Bootstrap 5 CSS via CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <!-- Modern Design System -->
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>

    <!-- ===== NAVBAR ===== -->
    <?php require __DIR__ . '/partials/navbar.php'; ?>

    <!-- ===== HERO SECTION ===== -->
    <section class="hero-section text-center">
        <div class="container position-relative" style="z-index: 2;">
            <div class="hero-badge mb-3">
                <i class="bi bi-stars text-warning"></i>
                <span>Toko Buku Digital Terpercaya</span>
            </div>
            <h1 class="mb-3">Temukan Buku Favorit &amp; Inspirasi Baru</h1>
            <p class="lead text-white-50 mx-auto mb-4" style="max-width: 600px; font-size: 1.05rem;">
                Jelajahi ribuan pilihan buku terlengkap mulai dari novel sastra, pengembangan diri, manga, hingga buku pelajaran.
            </p>

            <!-- Search Bar Modern -->
            <div class="hero-search-box">
                <form action="index.php" method="GET" class="d-flex align-items-center">
                    <?php if ($kategoriAktif): ?>
                        <input type="hidden" name="kategori" value="<?= htmlspecialchars($kategoriAktif['slug']) ?>">
                    <?php endif; ?>
                    <i class="bi bi-search text-white-50 ms-3 fs-5"></i>
                    <input
                        type="text"
                        name="cari"
                        class="form-control"
                        placeholder="<?= $kategoriAktif ? 'Cari di ' . htmlspecialchars($kategoriAktif['nama']) . '...' : 'Cari judul buku, penulis, atau topik...' ?>"
                        value="<?= htmlspecialchars($kataCari) ?>"
                        autocomplete="off"
                    >
                    <button class="btn btn-search me-1" type="submit">
                        Cari
                    </button>
                    <?php if ($kataCari !== '' || $kategoriAktif): ?>
                        <a href="index.php" class="btn btn-link text-white-50 p-2 me-1" title="Hapus filter">
                            <i class="bi bi-x-circle-fill fs-5"></i>
                        </a>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </section>

    <!-- ===== TRUST / HIGHLIGHTS BAR ===== -->
    <section class="trust-bar d-none d-md-block">
        <div class="container">
            <div class="row g-4 justify-content-between">
                <div class="col-md-3">
                    <div class="trust-item">
                        <div class="trust-icon">
                            <i class="bi bi-book"></i>
                        </div>
                        <div class="trust-text">
                            <h6><?= $totalSemuaBuku ?>+ Koleksi Buku</h6>
                            <p>Pilihan judul terlengkap</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="trust-item">
                        <div class="trust-icon">
                            <i class="bi bi-lightning-charge"></i>
                        </div>
                        <div class="trust-text">
                            <h6>Pengiriman Cepat</h6>
                            <p>Kemasan rapi &amp; terlindungi</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="trust-item">
                        <div class="trust-icon">
                            <i class="bi bi-qr-code-scan"></i>
                        </div>
                        <div class="trust-text">
                            <h6>QRIS &amp; Transfer Bank</h6>
                            <p>Pembayaran mudah &amp; otomatis</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="trust-item">
                        <div class="trust-icon">
                            <i class="bi bi-shield-check"></i>
                        </div>
                        <div class="trust-text">
                            <h6>100% Original</h6>
                            <p>Buku asli langsung penerbit</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== FILTER KATEGORI (STICKY) ===== -->
    <section class="category-filter-section py-3">
        <div class="container">
            <div class="d-flex align-items-center justify-content-between mb-2">
                <div class="d-flex align-items-center gap-2">
                    <span class="fw-bold small text-muted text-uppercase" style="letter-spacing: 0.05em;">
                        <i class="bi bi-grid-fill me-1 text-primary"></i>Kategori
                    </span>
                    <?php if ($kategoriAktif): ?>
                        <span class="badge bg-primary-subtle text-primary border border-primary-subtle">
                            <?= htmlspecialchars($kategoriAktif['nama']) ?>
                        </span>
                    <?php endif; ?>
                </div>

                <?php if ($kategoriAktif || $kataCari !== ''): ?>
                    <a href="index.php" class="small text-danger fw-semibold text-decoration-none">
                        <i class="bi bi-arrow-counterclockwise me-1"></i>Reset Filter
                    </a>
                <?php endif; ?>
            </div>

            <!-- Pills Navigasi Kategori -->
            <div class="category-pills-container d-flex flex-nowrap overflow-x-auto gap-2 pb-1">
                <!-- Tombol Semua -->
                <a
                    href="index.php<?= $kataCari !== '' ? '?cari=' . urlencode($kataCari) : '' ?>"
                    class="category-pill <?= !$kategoriAktif ? 'active' : '' ?>"
                >
                    <i class="bi bi-collection"></i>
                    <span>Semua</span>
                    <span class="badge rounded-pill ms-1 bg-secondary-subtle text-dark"><?= $totalSemuaBuku ?></span>
                </a>

                <!-- Daftar Kategori -->
                <?php foreach ($daftarKategori as $kat): ?>
                    <?php
                        $isActive = ($kategoriAktif && $kategoriAktif['id'] == $kat['id']);
                        $iconClass = getKategoriIcon($kat['slug']);
                        $linkQuery = ['kategori' => $kat['slug']];
                        if ($kataCari !== '') {
                            $linkQuery['cari'] = $kataCari;
                        }
                    ?>
                    <a
                        href="index.php?<?= http_build_query($linkQuery) ?>"
                        class="category-pill <?= $isActive ? 'active' : '' ?>"
                    >
                        <i class="bi <?= $iconClass ?>"></i>
                        <span><?= htmlspecialchars($kat['nama']) ?></span>
                        <span class="badge rounded-pill ms-1 <?= $isActive ? 'bg-warning text-dark' : 'bg-secondary-subtle text-dark' ?>">
                            <?= $kat['total_buku'] ?>
                        </span>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ===== KATALOG BUKU ===== -->
    <main class="container my-5 flex-grow-1">

        <!-- Banner Informasi Filter / Pencarian -->
        <?php if ($kategoriAktif || $kataCari !== ''): ?>
            <div class="alert bg-white border border-slate-200 shadow-sm rounded-4 d-flex align-items-center justify-content-between p-3 mb-4 flex-wrap gap-2" role="alert">
                <div class="d-flex align-items-center gap-3">
                    <div class="d-inline-flex p-2 rounded-3 bg-primary bg-opacity-10 text-primary">
                        <i class="bi bi-funnel-fill fs-5"></i>
                    </div>
                    <div>
                        <?php if ($kategoriAktif && $kataCari !== ''): ?>
                            <div class="fw-bold text-dark">Hasil Pencarian "<?= htmlspecialchars($kataCari) ?>"</div>
                            <div class="small text-muted">Kategori: <?= htmlspecialchars($kategoriAktif['nama']) ?> &bull; Ditemukan <?= $result->num_rows ?> buku</div>
                        <?php elseif ($kategoriAktif): ?>
                            <div class="fw-bold text-dark">Koleksi: <?= htmlspecialchars($kategoriAktif['nama']) ?></div>
                            <div class="small text-muted"><?= htmlspecialchars($kategoriAktif['deskripsi'] ?? 'Ditemukan ' . $result->num_rows . ' buku') ?></div>
                        <?php else: ?>
                            <div class="fw-bold text-dark">Hasil Pencarian "<?= htmlspecialchars($kataCari) ?>"</div>
                            <div class="small text-muted">Ditemukan <?= $result->num_rows ?> buku sesuai kata kunci</div>
                        <?php endif; ?>
                    </div>
                </div>
                <a href="index.php" class="btn btn-sm btn-outline-secondary">
                    <i class="bi bi-x-circle me-1"></i>Hapus Filter
                </a>
            </div>
        <?php endif; ?>

        <?php if ($result && $result->num_rows > 0): ?>
            <!-- Grid Koleksi Buku -->
            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4">
                <?php while ($buku = $result->fetch_assoc()): ?>
                    <div class="col">
                        <div class="book-card">
                            <!-- Image Container -->
                            <div class="book-card-image-wrapper">
                                <a href="detail.php?id=<?= $buku['id'] ?>">
                                    <img
                                        src="<?= $buku['cover'] ? htmlspecialchars($buku['cover']) : 'https://via.placeholder.com/300x400?text=No+Cover' ?>"
                                        alt="Cover <?= htmlspecialchars($buku['judul']) ?>"
                                        loading="lazy"
                                        onerror="this.src='https://via.placeholder.com/300x400?text=No+Cover'"
                                    >
                                </a>

                                <!-- Floating Category Badge -->
                                <?php if (!empty($buku['nama_kategori'])): ?>
                                    <a
                                        href="index.php?kategori=<?= urlencode($buku['slug_kategori'] ?? $buku['kategori_id']) ?>"
                                        class="card-badge-category text-decoration-none"
                                    >
                                        <i class="bi bi-tag-fill me-1"></i><?= htmlspecialchars($buku['nama_kategori']) ?>
                                    </a>
                                <?php endif; ?>

                                <!-- Stok Habis Overlay -->
                                <?php if ($buku['stok'] <= 0): ?>
                                    <span class="card-badge-stock-out">
                                        Stok Habis
                                    </span>
                                <?php endif; ?>
                            </div>

                            <!-- Card Body -->
                            <div class="card-body">
                                <h6 class="card-title">
                                    <a href="detail.php?id=<?= $buku['id'] ?>" class="text-dark text-decoration-none">
                                        <?= htmlspecialchars($buku['judul']) ?>
                                    </a>
                                </h6>
                                <div class="author-text">
                                    <i class="bi bi-person me-1"></i><?= htmlspecialchars($buku['penulis']) ?>
                                </div>
                                <div class="publisher-text">
                                    <i class="bi bi-building me-1"></i><?= htmlspecialchars($buku['penerbit']) ?>
                                </div>

                                <div class="price-row">
                                    <div>
                                        <div class="small text-muted" style="font-size: 0.72rem;">Harga</div>
                                        <div class="price-tag">
                                            Rp <?= number_format($buku['harga'], 0, ',', '.') ?>
                                        </div>
                                    </div>
                                    <div>
                                        <?php if ($buku['stok'] > 10): ?>
                                            <span class="badge bg-success-subtle text-success small">
                                                Stok <?= $buku['stok'] ?>
                                            </span>
                                        <?php elseif ($buku['stok'] > 0): ?>
                                            <span class="badge bg-warning-subtle text-warning small">
                                                Sisa <?= $buku['stok'] ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-danger-subtle text-danger small">
                                                Habis
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <!-- Actions -->
                                <div class="card-actions">
                                    <a href="detail.php?id=<?= $buku['id'] ?>" class="btn btn-outline-secondary btn-sm d-flex align-items-center justify-content-center">
                                        <i class="bi bi-eye me-1"></i>Detail
                                    </a>
                                    <form action="proses_cart.php" method="POST" class="m-0">
                                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">
                                        <input type="hidden" name="aksi" value="tambah">
                                        <input type="hidden" name="id_buku" value="<?= (int) $buku['id'] ?>">
                                        <button
                                            type="submit"
                                            class="btn btn-warning btn-sm d-flex align-items-center justify-content-center px-3"
                                            <?= $buku['stok'] <= 0 ? 'disabled' : '' ?>
                                            title="<?= $buku['stok'] > 0 ? 'Tambah ke Keranjang' : 'Stok habis' ?>"
                                        >
                                            <i class="bi bi-cart-plus-fill"></i>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>

        <?php else: ?>
            <!-- State Kosong / Tidak Ditemukan -->
            <div class="card border-0 shadow-sm rounded-4 text-center py-5 my-4 bg-white">
                <div class="card-body">
                    <div class="d-inline-flex p-4 rounded-circle bg-light text-muted mb-3">
                        <i class="bi bi-inbox display-3 text-secondary"></i>
                    </div>
                    <h4 class="fw-bold mb-2">Buku Tidak Ditemukan</h4>
                    <p class="text-muted mb-4 mx-auto" style="max-width: 480px;">
                        <?php if ($kategoriAktif): ?>
                            Belum ada koleksi buku untuk kategori <strong>"<?= htmlspecialchars($kategoriAktif['nama']) ?>"</strong>.
                        <?php else: ?>
                            Kata kunci yang Anda cari tidak cocok dengan koleksi yang tersedia. Coba gunakan kata kunci lain atau lihat seluruh katalog.
                        <?php endif; ?>
                    </p>
                    <a href="index.php" class="btn btn-primary px-4 py-2">
                        <i class="bi bi-arrow-left me-1"></i>Lihat Semua Koleksi Buku
                    </a>
                </div>
            </div>
        <?php endif; ?>

    </main>

    <!-- ===== FOOTER ===== -->
    <footer class="modern-footer">
        <div class="container">
            <div class="row g-4 mb-4">
                <div class="col-lg-4">
                    <div class="d-flex align-items-center gap-2 mb-3">
                        <span class="brand-icon-box" style="width: 32px; height: 32px;">
                            <i class="bi bi-book-half"></i>
                        </span>
                        <span class="h5 mb-0 text-white fw-bold">BukuKu</span>
                    </div>
                    <p class="small text-slate-400 mb-3" style="line-height: 1.6;">
                        Platform toko buku digital modern yang menyediakan ribuan pilihan buku terlengkap dengan kemudahan transaksi dan pengalaman membaca terbaik.
                    </p>
                    <div class="d-flex gap-2">
                        <a href="#" class="btn btn-sm btn-outline-secondary text-white rounded-circle p-2" style="width: 34px; height: 34px;"><i class="bi bi-instagram"></i></a>
                        <a href="#" class="btn btn-sm btn-outline-secondary text-white rounded-circle p-2" style="width: 34px; height: 34px;"><i class="bi bi-twitter-x"></i></a>
                        <a href="#" class="btn btn-sm btn-outline-secondary text-white rounded-circle p-2" style="width: 34px; height: 34px;"><i class="bi bi-facebook"></i></a>
                    </div>
                </div>

                <div class="col-6 col-lg-2">
                    <h6>Navigasi</h6>
                    <ul class="list-unstyled small">
                        <li class="mb-2"><a href="index.php">Katalog Buku</a></li>
                        <li class="mb-2"><a href="cart.php">Keranjang Belanja</a></li>
                        <li class="mb-2"><a href="pesanan.php">Riwayat Pesanan</a></li>
                        <li class="mb-2"><a href="login.php">Masuk Akun</a></li>
                    </ul>
                </div>

                <div class="col-6 col-lg-3">
                    <h6>Kategori Populer</h6>
                    <ul class="list-unstyled small">
                        <?php foreach (array_slice($daftarKategori, 0, 5) as $fk): ?>
                            <li class="mb-2">
                                <a href="index.php?kategori=<?= urlencode($fk['slug']) ?>">
                                    <?= htmlspecialchars($fk['nama']) ?>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>

                <div class="col-lg-3">
                    <h6>Metode Pembayaran</h6>
                    <p class="small text-slate-400 mb-3">Mendukung pembayaran digital instan dan transfer bank nasional.</p>
                    <div class="d-flex flex-wrap gap-2">
                        <span class="badge bg-secondary-subtle text-dark border px-2 py-1">QRIS</span>
                        <span class="badge bg-secondary-subtle text-dark border px-2 py-1">BCA</span>
                        <span class="badge bg-secondary-subtle text-dark border px-2 py-1">Mandiri</span>
                    </div>
                </div>
            </div>

            <hr class="border-secondary opacity-25 my-4">

            <div class="d-flex flex-column flex-md-row justify-content-between align-items-center small text-slate-400 gap-2">
                <div>&copy; <?= date('Y') ?> BukuKu Store &mdash; Digital Bookstore. All rights reserved.</div>
                <div>Dirancang dengan antarmuka modern &amp; responsif</div>
            </div>
        </div>
    </footer>

    <!-- Bootstrap 5 JS Bundle via CDN -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/script.js"></script>
</body>
</html>
